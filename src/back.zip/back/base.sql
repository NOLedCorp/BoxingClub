CREATE TABLE IF NOT EXISTS sections (
	SectionId int(20) PRIMARY KEY AUTO_INCREMENT,
    Name varchar(255),
    Description text,
    Price float,
    Image varchar(255),
    ModifyDate datetime DEFAULT CURRENT_TIMESTAMP,
    Adress varchar(255)
);

CREATE TABLE IF NOT EXISTS deals (
	DealId int(20) PRIMARY KEY AUTO_INCREMENT,
    SectionId int(20),
    Email varchar(255),
    Phone varchar(20),
    Name varchar(255),
    CreateDate datetime DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT du_fk FOREIGN KEY(SectionId) REFERENCES sections(SectionId)
);



